package com.example.androidweatherappv2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class FactsFragment extends Fragment {
    static FactsFragment instance;
    public static FactsFragment getInstance() {
        if(instance == null)
            instance = new FactsFragment();
        return instance;
    }

    public FactsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_facts, container, false);
    }
}