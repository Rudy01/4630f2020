package com.example.schoolplanner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GradeDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade_details);
    }
}