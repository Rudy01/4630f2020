package com.example.schoolplanner.logic.objects;

public class Grade {
    private final int id;
    private final Subject subject;
    private final String name;
    private final String grade;

    public Grade(int id, Subject subject, String name, String grade) {
        this.id = id;
        this.subject = subject;
        this.name = name;
        this.grade = grade;
    }

    public int getId() {
        return id;
    }
    public Subject getSubject() {
        return subject;
    }
    public String getName() {
        return name;
    }
    public String getGrade() {
        return grade;
    }

    @Override
    public String toString() {
        return "---Grade--- \n" +
                "Id: \t" + id + "\n" +
                subject.toString() + "\n" +
                "Name: \t" + name + "\n" +
                "Grade: \t" + grade + "\n" +
                "---####---";
    }
}
