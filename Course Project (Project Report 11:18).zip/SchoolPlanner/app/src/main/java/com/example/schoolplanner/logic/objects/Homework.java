package com.example.schoolplanner.logic.objects;


import java.util.Calendar;
import java.util.GregorianCalendar;

public class Homework {
    private final int id;
    private final Subject subject;
    private final String description;
    private final GregorianCalendar deadline;
    private boolean done;

    public Homework(int id, Subject subject, String description, GregorianCalendar deadline, boolean done) {
        this.id = id;
        this.subject = subject;
        this.description = description;
        this.deadline = deadline;
        this.done = done;
    }

    public Homework(int id, Subject subject, String description, String deadline, boolean done) {
        this.id = id;
        this.subject = subject;
        this.description = description;
        this.deadline = convertDateStringToGregorianCalendar(deadline);
        this.done = done;
    }

    public int getId() {
        return id;
    }
    public Subject getSubject() {
        return subject;
    }
    public String getDescription() {
        return description;
    }
    public GregorianCalendar getDeadline() {
        return deadline;
    }

    public String getDeadlineAsDatabaseString() {
        return deadline.get(Calendar.YEAR) + "-" + String.valueOf(deadline.get(Calendar.MONTH) + 1) + "-" + deadline.get(Calendar.DAY_OF_MONTH);
    }

    public boolean isDone() {
        return done;
    }

    public int getDone() {
        if (done) {
            return 1;
        } else {
            return 0;
        }
    }

    @Override
    public String toString() {
        return "---Homework--- \n" +
                "Id: \t" + id + "\n" +
                subject.toString() + "\n" +
                "Description: \t" + description + "\n" +
                "Deadline: \t" + getDeadlineAsDatabaseString() + "\n" +
                "Done: \t" + done + "\n" +
                "---####---";
    }

    private GregorianCalendar convertDateStringToGregorianCalendar(String source) {
        String[] date = source.split("-");

        return new GregorianCalendar(
                Integer.parseInt(date[0]),
                Integer.parseInt(date[1]) - 1,
                Integer.parseInt(date[2])
        );
    }
}
