package com.example.schoolplanner.logic.objects;

import androidx.annotation.NonNull;

public class Lesson implements Comparable<Lesson> {
    private final int id;
    private final Subject subject;
    private final Period period;

    public Lesson(int id, Subject subject, Period period) {
        this.id = id;
        this.subject = subject;
        this.period = period;
    }

    public static boolean match(Lesson[] lessons, Lesson[] otherLessons) {
        if (lessons.length != otherLessons.length) {
            return false;
        }

        for (int i = 0; i < lessons.length; i++) {
            if (!lessons[i].match(otherLessons[i])) {
                return false;
            }
        }

        return true;
    }

    public int getId() {
        return id;
    }
    public Subject getSubject() {
        return subject;
    }
    public Period getPeriod() {
        return period;
    }

    public boolean match(Lesson otherLesson) {
        return this.id == otherLesson.id && this.subject.match(otherLesson.subject) &&
                this.period.match(otherLesson.period)
                ;
    }

    @Override
    public String toString() {
        return "---Period--- \n" +
                "Id: \t" + id + "\n" +
                subject.toString() + "\n" +
                period.toString() + "\n" +
                "---####---"
                ;
    }

    @Override
    public int compareTo(@NonNull Lesson lesson) {
        return this.period.compareTo(lesson.period);
    }
}
