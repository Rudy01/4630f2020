package com.example.schoolplanner.logic.objects;

public class Subject {
    public static final String DEFAULT_COLOR = "#e0e0e0";
    private final int id;
    private final Teacher teacher;
    private final String name;
    private final String room;
    private final String color;

    public Subject(int id, Teacher teacher, String name, String room, String color) {
        this.id = id;
        this.teacher = teacher;
        this.name = name;
        this.room = room;
        this.color = color;
    }

    public int getId() {
        return id;
    }
    public Teacher getTeacher() {
        return teacher;
    }
    public String getName() {
        return name;
    }
    public String getRoom() {
        return room;
    }
    public String getColor() {
        return color;
    }

    public boolean match(Subject otherSubject) {
        return this.id == otherSubject.id && this.teacher.match(otherSubject.teacher) &&
                this.name.equals(otherSubject.name)
                && this.room.equals(otherSubject.room)
                && this.color.equals(otherSubject.color);
    }


    @Override
    public String toString() {
        return "---Subject--- \n" +
                "Id: \t" + id + "\n" +
                teacher.toString() + "\n" +
                "Name: \t" + name + "\n" +
                "Room: \t" + room + "\n" +
                "Color: \t#" + color + "\n" +
                "---####---";
    }
}