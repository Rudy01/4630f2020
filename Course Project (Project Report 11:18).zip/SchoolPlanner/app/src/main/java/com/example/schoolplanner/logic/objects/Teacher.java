package com.example.schoolplanner.logic.objects;

import androidx.annotation.Nullable;

import java.util.Objects;

public class Teacher {
    public static final char MALE = 'm';
    public static final char FEMALE = 'f';

    private final int id;
    private final String name;
    private final String abbreviation;
    private final char gender;

    public Teacher(int id, String name, @Nullable String abbreviation, char gender) {
        this.id = id;
        this.name = name;
        this.abbreviation = abbreviation;
        this.gender = gender;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getAbbreviation() {
        return abbreviation;
    }
    public char getGender() {
        return gender;
    }

    public boolean match(Teacher otherTeacher) {
        return this.id == otherTeacher.id && this.name.equals(otherTeacher.name) &&
                Objects.requireNonNull(this.abbreviation).equals(otherTeacher.abbreviation)
                && this.gender == otherTeacher.gender;
    }

    @Override
    public String toString() {
        return "---Teacher--- \n" +
                "Id: \t" + id + "\n" +
                "Name: \t" + name + "\n" +
                "Abbreviation: \t" + abbreviation + "\n" +
                "Gender: \t" + gender + "\n" +
                "---######---";
    }
}