package com.example.schoolplanner.logic.objects;

import java.util.Arrays;

public class Weekday {
    public static final String MONDAY = "monday";
    public static final String TUESDAY = "tuesday";
    public static final String WEDNESDAY = "wednesday";
    public static final String THURSDAY = "thursday";
    public static final String FRIDAY = "friday";
    public static final String SATURDAY = "saturday";

    private final int id;
    private final String name;
    private final Lesson[] lessons;

    public Weekday(int id, String name, Lesson[] lessons) {
        this.id = id;
        this.name = name;
        Arrays.sort(lessons);
        this.lessons = lessons;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public Lesson[] getLessons() {
        return lessons;
    }

    public boolean match(Weekday otherWeekday) {
        return this.id == otherWeekday.id && this.name.equals(otherWeekday.name) &&
                Lesson.match(this.lessons, otherWeekday.lessons);
    }

    @Override
    public String toString() {
        return "---Weekday--- \n" +
                "Id: \t" + id + "\n" +
                "Name: \t" + name + "\n" +
                "Periods: \t" + Arrays.toString(lessons) + "\n" +
                "---######---";
    }


}