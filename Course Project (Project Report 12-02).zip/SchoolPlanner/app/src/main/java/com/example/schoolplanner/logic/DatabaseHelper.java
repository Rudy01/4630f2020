package com.example.schoolplanner.logic;

import android.content.Context;

import com.example.schoolplanner.logic.objects.Exam;
import com.example.schoolplanner.logic.objects.Grade;
import com.example.schoolplanner.logic.objects.Homework;
import com.example.schoolplanner.logic.objects.Lesson;
import com.example.schoolplanner.logic.objects.Period;
import com.example.schoolplanner.logic.objects.Schedule;
import com.example.schoolplanner.logic.objects.Subject;
import com.example.schoolplanner.logic.objects.Teacher;
import com.example.schoolplanner.logic.objects.Weekday;

@SuppressWarnings({"FieldNever", "unused"})
public interface DatabaseHelper {
    int DATABASE_VERSION = 1;
    String DATABASE_NAME = "SchoolPlaner.db";
    String TABLE_SUBJECT = "subject";
    String SUBJECT_COLUMN_ID = "subject_id";
    String SUBJECT_COLUMN_TEACHER_ID = "subject_teacher_id";
    String SUBJECT_COLUMN_NAME = "subject_name";
    String SUBJECT_COLUMN_ROOM = "subject_room";
    String SUBJECT_COLUMN_COLOR = "subject_color";
    String TABLE_TEACHER = "teacher";
    String TEACHER_COLUMN_ID = "teacher_id";
    String TEACHER_COLUMN_NAME = "teacher_name";
    String TEACHER_COLUMN_ABBREVIATION = "teacher_abbreviation";
    String TEACHER_COLUMN_GENDER = "teacher_gender";
    String TABLE_HOMEWORK = "homework";
    String HOMEWORK_COLUMN_ID = "homework_id";
    String HOMEWORK_COLUMN_SUBJECT_ID = "homework_subject_id";
    String HOMEWORK_COLUMN_DESCRIPTION = "homework_description";
    String HOMEWORK_COLUMN_DEADLINE = "homework_deadline";
    String HOMEWORK_COLUMN_DONE = "homework_done";
    String TABLE_EXAM = "exam";
    String EXAM_COLUMN_ID = "exam_id";
    String EXAM_COLUMN_SUBJECT_ID = "exam_subject_id";
    String EXAM_COLUMN_DESCRIPTION = "exam_description";
    String EXAM_COLUMN_DEADLINE = "exam_deadline";
    String TABLE_GRADE = "grade";
    String GRADE_COLUMN_ID = "grade_id";
    String GRADE_COLUMN_SUBJECT_ID = "grade_subject_id";
    String GRADE_COLUMN_NAME = "grade_name";
    String GRADE_COLUMN_GRADE = "grade_grade";
    String TABLE_PERIOD = "period";
    String PERIOD_COLUMN_ID = "period_id";
    String PERIOD_COLUMN_SCHOOL_HOUR_NO = "period_column_school_hour_no";
    String PERIOD_COLUMN_STARTTIME = "period_starttime";
    String PERIOD_COLUMN_ENDTIME = "period_endtime";
    String TABLE_LESSON = "lesson";
    String LESSON_COLUMN_ID = "lesson_id";
    String LESSON_COLUMN_SUBJECT_ID = "lesson_column_subject_id";
    String LESSON_COLUMN_PERIOD_ID = "lesson_column_period_id";
    String LESSON_COLUMN_WEEKDAY_ID = "lesson_column_weekday_id";
    String TABLE_WEEKDAY = "weekday";
    String WEEKDAY_COLUMN_ID = "weekday_id";
    String WEEKDAY_COLUMN_SCHEDULE_ID = "weekday_schedule_id";
    String WEEKDAY_COLUMN_NAME = "weekday_name";
    String TABLE_SCHEDULE = "schedule";
    String SCHEDULE_COLUMN_ID = "schedule_id";
    String SCHEDULE_COLUMN_NAME = "schedule_name";

    Subject getSubjectAtId(int id);
    Teacher getTeacherAtId(int id);
    Homework getHomeworkAtId(int id);
    Exam getExamAtId(int id);
    Grade getGradeAtId(int id);
    Period getPeriodAtId(int id);
    Lesson getLessonAtId(int id);
    Weekday getWeekdayAtId(int id);
    Schedule getScheduleAtId(int id);

    void updateSubjectAtId(Subject newSubject);
    void updateTeacherAtId(Teacher newTeacher);
    void updateHomeworkAtId(Homework newHomework);
    void updateExamAtId(Exam newExam);
    void updateGradeAtId(Grade newGrade);
    void updateLessonAtId(Lesson newLesson);
    void updatePeriodAtId(Period newPeriod);
    void updateWeekdayAtId(Weekday newWeekday);
    void updateScheduleAtId(Schedule newSchedule);

    int insertIntoDB(Subject subject);
    int insertIntoDB(Teacher teacher);
    int insertIntoDB(Homework homework);
    int insertIntoDB(Exam exam);
    int insertIntoDB(Grade grade);
    int insertIntoDB(Period period);
    int insertIntoDB(Lesson lesson);
    int insertIntoDB(Weekday weekday);
    int insertIntoDB(Schedule schedule);

    void deleteSubjectAtId(int id);
    void deleteTeacherAtId(int id);
    void deleteHomeworkAtId(int id);
    void deleteExamAtId(int id);
    void deleteGradeAtId(int id);
    void deleteLessonAtId(int id);
    void deleteScheduleAtId(int id);

    Subject getSubjectAtIdOrThrow(int id) throws NoSuchFieldException;
    Teacher getTeacherAtIdOrThrow(int id) throws NoSuchFieldException;
    Homework getHomeworkAtIdOrThrow(int id) throws NoSuchFieldException;
    Exam getExamAtIdOrThrow(int id) throws NoSuchFieldException;
    Grade getGradeAtIdOrThrow(int id) throws NoSuchFieldException;
    Period getPeriodAtIdOrThrow(int id) throws NoSuchFieldException;
    Lesson getLessonAtIdOrThrow(int id) throws NoSuchFieldException;
    Weekday getWeekdayAtIdOrThrow(int id) throws NoSuchFieldException;
    Schedule getScheduleAtIdOrThrow(int id) throws NoSuchFieldException;

    void updateSubjectAtIdOrThrow(Subject newSubject) throws NoSuchFieldException;
    void updateTeacherAtIdOrThrow(Teacher newTeacher) throws NoSuchFieldException;
    void updateHomeworkAtIdOrThrow(Homework newHomework) throws NoSuchFieldException;
    void updateExamAtIdOrThrow(Exam newExam) throws NoSuchFieldException;
    void updateGradeAtIdOrThrow(Grade newGrade) throws NoSuchFieldException;
    void updatePeriodAtIdOrThrow(Period newPeriod) throws NoSuchFieldException;
    void updateLessonAtIdOrThrow(Lesson newLesson) throws NoSuchFieldException;
    void updateWeekdayAtIdOrThrow(Weekday newWeekday) throws NoSuchFieldException;
    void updateScheduleAtIdOrThrow(Schedule newSchedule) throws NoSuchFieldException;

    int insertIntoDBOrThrow(Subject subject) throws IllegalAccessException;
    int insertIntoDBOrThrow(Teacher teacher) throws IllegalAccessException;
    int insertIntoDBOrThrow(Homework homework) throws IllegalAccessException;
    int insertIntoDBOrThrow(Exam exam) throws IllegalAccessException;
    int insertIntoDBOrThrow(Grade grade) throws IllegalAccessException;
    int insertIntoDBOrThrow(Period period) throws IllegalAccessException;
    int insertIntoDBOrThrow(Lesson lesson) throws IllegalAccessException;
    int insertIntoDBOrThrow(Weekday weekday) throws IllegalAccessException;
    int insertIntoDBOrThrow(Schedule schedule) throws IllegalAccessException;

    void deleteSubjectAtIdOrThrow(int id) throws NoSuchFieldException;
    void deleteTeacherAtIdOrThrow(int id) throws NoSuchFieldException;
    void deleteHomeworkAtIdOrThrow(int id) throws NoSuchFieldException;
    void deleteExamAtIdOrThrow(int id) throws NoSuchFieldException;
    void deleteGradeAtIdOrThrow(int id) throws NoSuchFieldException;
    void deletePeriodAtIdOrThrow(int id) throws NoSuchFieldException;
    void deleteLessonAtIdOrThrow(int id) throws NoSuchFieldException;
    void deleteWeekdayAtIdOrThrow(int id) throws NoSuchFieldException;
    void deleteScheduleAtIdOrThrow(int id) throws NoSuchFieldException;

    @Override
    String toString();
    String toString(String tableName);

    int size(String tableName);
    int[] getIndices(String tableName);

    void resetDatabase();
}
