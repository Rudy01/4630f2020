package com.example.schoolplanner;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.schoolplanner.logic.DatabaseHelper;
import com.example.schoolplanner.logic.DatabaseHelperImpl;
import com.example.schoolplanner.logic.objects.Exam;

import java.util.ArrayList;
import java.util.Objects;

public class ExamsFragment extends Fragment implements View.OnClickListener {
    @SuppressWarnings({"FieldNever", "unused"})
    private OnFragmentInteractionListener mListener;
    private View view;
    private Exam[] allExamsInList;

    @SuppressLint("UseRequireInsteadOfGet")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Objects.requireNonNull(getActivity()).setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener)
            mListener = (OnFragmentInteractionListener) context;
        else
            throw new RuntimeException(context.toString() + " must implemnt OnFragmentInteractionListener");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.exams_floatingActionButton_add:
                startActivity(new Intent(getContext(), ExamDetailsActivity.class));
        }
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    private void initGUI() {
        GuiHelper.defineFloatingActionButtonOnClickListener(view, R.id.exams_floatingActionButton_add, this);
        allExamsInList = fillListView();
        defineExamListOnClick(view);
    }

    private Exam[] fillListView() {
        DatabaseHelper dbHelper = new DatabaseHelperImpl(view.getContext());

        ArrayList<String> examStrings = new ArrayList<>();
        ArrayList<Exam> examArrayList = new ArrayList<>();
        int[] examIndices = dbHelper.getIndices(DatabaseHelper.TABLE_EXAM);

        for (int examIndex : examIndices) {
            Exam exam = dbHelper.getExamAtId(examIndex);

            examStrings.add(GuiHelper.extractGuiString(exam, getContext()));
            examArrayList.add(exam);
        }

        if (examStrings.size() != 0)
            GuiHelper.fillListViewFromArray(view, R.id.exams_listExams, examStrings.toArray(new String[0]));

        return examArrayList.toArray(new Exam[0]);
    }

    private void defineExamListOnClick(final View view) {
        ListView subjectList = view.findViewById(R.id.exams_listExams);

        subjectList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
                Intent intent = new Intent(getContext(), ExamDetailsActivity.class);
                intent.putExtra("ExamID", allExamsInList[position].getId());
                startActivity(intent);
            }
        });
    }

    private void initToolbarTitle() {
        @SuppressLint("UseRequireInsteadOfGet")
        Toolbar toolbar = Objects.requireNonNull(getActivity()).findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.string_exams);
    }
}