package com.example.schoolplanner.logic.objects;

import androidx.annotation.NonNull;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Period implements Comparable<Period> {
    private final int id;
    private final int schoolHourNo;
    private final GregorianCalendar startTime;
    private final GregorianCalendar endTime;

    public Period(int id, int schoolHourNo, GregorianCalendar startTime, GregorianCalendar endTime) {
        this.id = id;
        this.schoolHourNo = schoolHourNo;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public Period(int id, int schoolHourNo, String startTime, String endTime) {
        this.id = id;
        this.schoolHourNo = schoolHourNo;
        this.startTime = convertTimeStringToGregorianCalendar(startTime);
        this.endTime = convertTimeStringToGregorianCalendar(endTime);
    }

    public int getId() {
        return id;
    }

    public int getSchoolHourNo() {
        return schoolHourNo;
    }

    public GregorianCalendar getStartTime() {
        return startTime;
    }

    public String getStartTimeAsString() {
        return startTime.get(Calendar.HOUR_OF_DAY) + "-" + startTime.get(Calendar.MINUTE) + "-" + startTime.get(Calendar.SECOND);
    }

    /**
     * gets the time the period ends
     *
     * @return the time the period ends as GregorianCalendar
     */
    public GregorianCalendar getEndTime() {
        return endTime;
    }
    //endregion

    public String getEndTimeAsString() {
        return endTime.get(Calendar.HOUR_OF_DAY) + "-" + endTime.get(Calendar.MINUTE) + "-" + endTime.get(Calendar.SECOND);
    }

    public boolean match(Period otherPeriod) {
        return this.id == otherPeriod.id && this.schoolHourNo == otherPeriod.schoolHourNo &&
                this.startTime.equals(otherPeriod.startTime) && this.endTime.equals(otherPeriod.endTime);
    }

    @Override
    public String toString() {
        return "---Period--- \n" +
                "Id: \t" + id + "\n" +
                "SchoolHourNo: \t" + schoolHourNo + "\n" +
                "StartTime: \t" + startTime.get(Calendar.HOUR_OF_DAY) + "-" + startTime.get(Calendar.MINUTE) + "-" + startTime.get(Calendar.SECOND) + "\n" +
                "EndTime: \t" + endTime.get(Calendar.HOUR_OF_DAY) + "-" + endTime.get(Calendar.MINUTE) + "-" + endTime.get(Calendar.SECOND) + "\n" +
                "---####---";
    }

    @Override
    public int compareTo(@NonNull Period period) {
        return Integer.compare(this.schoolHourNo, period.schoolHourNo);
    }

    private GregorianCalendar convertTimeStringToGregorianCalendar(String source) {
        return new GregorianCalendar(
                0,
                0,
                0,
                Integer.parseInt(source.split("-")[0]),
                Integer.parseInt(source.split("-")[1]),
                Integer.parseInt(source.split("-")[2])
        );
    }
}