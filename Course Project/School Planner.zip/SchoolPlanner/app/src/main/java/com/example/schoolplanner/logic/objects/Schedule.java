package com.example.schoolplanner.logic.objects;

import java.util.Arrays;

public class Schedule {
    private int id;
    private String name;
    private Weekday[] days;

    public Schedule(int id, String name, Weekday[] weekdays) {
        if (weekdays.length > 6) {
            throw new ArrayIndexOutOfBoundsException("array length " + weekdays.length + " isn't a supported Week, which length would be 6 or less");
        } else {
            this.id = id;
            this.name = name;
            this.days = weekdays;
        }
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Weekday[] getDays() {
        return days;
    }

    public Weekday getDay(String name) {
        for (Weekday day : days) {
            if (day != null) {
                if (day.getName().equals(name)) {
                    return day;
                }
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "---Schedule--- \n" +
                "Id: \t" + id + "\n" +
                "Name: \t" + name + "\n" +
                "Days: \t" + Arrays.toString(days) + "\n" +
                "---######---";
    }
}